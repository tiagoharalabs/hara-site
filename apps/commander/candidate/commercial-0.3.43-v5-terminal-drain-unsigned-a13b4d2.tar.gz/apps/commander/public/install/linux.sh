#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${HARA_COMMANDER_URL:-https://commander.haralabs.com.br}"
RELEASE_SIGNING_KID="commander-release-v2"
RELEASE_SIGNING_N="p9ylK_Yf48aEfkps9ZVm6u5Uk3haKCF1ltQmZUrXHLqrbiXf4L-3OdqpYcv7VGktbXKVfccIR2-b8lfNPKT-OpemqcgkJ9Cb-gvjxdPxoLOWxTVasKr8ttUirM08LVzL7BF3Mwadl2SEQXSHC0ayH1Jtj3-57Z8XNZ4NvWuUswBhYrNtXpe8-a86HSy2r0pEMWZalqJE1mD1nGnODYWLpsLPkTX4rUBky5zBX11Rkf2_Op3jpo5nwWVPf2AEJSq-yogQQI3jopJRydnrDySxFpI7TgN1SAL1nEcNRkh-rOjchuqyHpQAN2DSDpQvrFDxANDLMhxrlwmE6MU4PAn46ICuKgyqAYULlVhYhjZpPUZpLHvwG3rjYbD022qYbBDdamJ79FWcoDxmr85mwiDQ4WDEn8cgF_5G2pmq6Wq3ss2O1cQJB_QgkID3uBeywonGs0ikoMtxmIvSi1HVGkBVC0Ay726K9wwpT_xhiwVT_OpAnNYgNdqWcc-cU7n-Zt43"
RELEASE_SIGNING_E="AQAB"
CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/hara-commander"
BIN_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/hara-commander"
USER_BIN="${HOME}/.local/bin"
SYSTEMD_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
CONFIG_FILE="$CONFIG_DIR/device.env"
ENROLLMENT_INTENT="$CONFIG_DIR/enrollment-intent.json"
AGENT="$BIN_DIR/hara-commander-agent"
CLI="$USER_BIN/hara-commander"
TUNNEL_CLIENT="$BIN_DIR/tunnel-client"
TUNNEL_CLIENT_VERSION="0.0.15"
TUNNEL_CLIENT_BASE_URL="https://persistent.oaistatic.com/tunnel-client/v0.0.15"
TUNNEL_CLIENT_SHA256_AMD64="8c836dc5d68d68b663d9a5c5b28ff9fa780d9f7a3fffb1c306880b8f32fab5f1"
TUNNEL_CLIENT_SHA256_ARM64="c51bfd883fc22e3445494a03c0179875176564bde470661b308fd83af5d01abb"
UNIT="$SYSTEMD_DIR/hara-commander-agent.service"
SERVICE="hara-commander-agent.service"
STATUS_FILE="$BIN_DIR/runtime-status.json"
APPROVAL_MODE_RAW="${HARA_COMMANDER_APPROVAL_MODE:-}"
TRANSPORT_MODE_RAW="${HARA_COMMANDER_TRANSPORT_MODE:-}"
TUNNEL_AUTOSTART_RAW="${HARA_COMMANDER_TUNNEL_AUTOSTART:-}"
ACTION="${1:-install}"
ACTION="${ACTION#--}"
REENROLL=FALSE
REENROLL_BACKUP=""
REENROLL_CONFIG_REPLACED=FALSE
REENROLL_SERVICE_WAS_ACTIVE=FALSE
RELEASE_WORKDIR=""
VERIFIED_AGENT_SOURCE=""

# Reattach to the existing per-user systemd/DBus runtime when invoked from
# non-graphical SSH/automation sessions that omit the usual desktop env.
if [ -z "${XDG_RUNTIME_DIR:-}" ] && [ -d "/run/user/$(id -u)" ]; then
  export XDG_RUNTIME_DIR="/run/user/$(id -u)"
fi
if [ -n "${XDG_RUNTIME_DIR:-}" ] && [ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ] && [ -S "$XDG_RUNTIME_DIR/bus" ]; then
  export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
fi

need() {
  command -v "$1" >/dev/null 2>&1 || {
    printf 'HARA Commander requires %s.\n' "$1" >&2
    exit 2
  }
}

need curl
need python3
need systemctl

verify_release_manifest_signature() {
  local manifest="$1" signature="$2"
  python3 - "$manifest" "$signature" "$RELEASE_SIGNING_KID" "$RELEASE_SIGNING_N" "$RELEASE_SIGNING_E" <<'PYRELEASESIG'
import base64,hashlib,hmac,json,sys
manifest_path,sig_path,kid,n_b64,e_b64=sys.argv[1:6]
def b64ud(value):
    return base64.urlsafe_b64decode(value+"="*((4-len(value)%4)%4))
raw=open(manifest_path,"rb").read()
obj=json.load(open(sig_path,encoding="utf-8"))
if obj.get("schema")!="hara.commander-release-signature.v1": raise SystemExit(2)
if obj.get("alg")!="RS256": raise SystemExit(2)
if obj.get("kid")!=kid: raise SystemExit(12)
if obj.get("manifest_sha256")!=hashlib.sha256(raw).hexdigest(): raise SystemExit(3)
sig=b64ud(str(obj.get("signature") or ""))
n=int.from_bytes(b64ud(n_b64),"big"); e=int.from_bytes(b64ud(e_b64),"big")
size=(n.bit_length()+7)//8
if len(sig)!=size: raise SystemExit(4)
em=pow(int.from_bytes(sig,"big"),e,n).to_bytes(size,"big")
digest_info=bytes.fromhex("3031300d060960864801650304020105000420")+hashlib.sha256(raw).digest()
padding=size-len(digest_info)-3
expected=b"\x00\x01"+(b"\xff"*padding)+b"\x00"+digest_info
if padding<8 or not hmac.compare_digest(em,expected): raise SystemExit(5)
PYRELEASESIG
}

read_config_value() {
  local key="$1"
  [ -f "$CONFIG_FILE" ] || return 1
  python3 - "$CONFIG_FILE" "$key" <<'PY'
from pathlib import Path
import sys
path=Path(sys.argv[1]); key=sys.argv[2]
for raw in path.read_text(encoding="utf-8").splitlines():
    if raw.startswith(key+"="):
        print(raw.split("=",1)[1]); raise SystemExit(0)
raise SystemExit(1)
PY
}

prepare_enrollment_intent() {
  local pairing_hash="$1"
  [ ! -L "$CONFIG_DIR" ] || { echo 'ENROLLMENT_INTENT_DIRECTORY_UNSAFE' >&2; return 1; }
  (umask 077; mkdir -p "$CONFIG_DIR")
  chmod 700 "$CONFIG_DIR"
  python3 - "$ENROLLMENT_INTENT" "$pairing_hash" <<'PYENROLLINTENT'
import json,os,pathlib,re,secrets,stat,sys
path=pathlib.Path(sys.argv[1]); pairing_hash=sys.argv[2]
if path.is_symlink(): raise SystemExit('ENROLLMENT_INTENT_UNSAFE')
if path.exists():
    info=path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or stat.S_IMODE(info.st_mode)!=0o600:
        raise SystemExit('ENROLLMENT_INTENT_UNSAFE')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        with os.fdopen(fd,encoding='utf-8') as file: intent=json.load(file)
    except (OSError,ValueError):
        raise SystemExit('ENROLLMENT_INTENT_INVALID') from None
    if intent.get('schema')!='hara.commander-enrollment-intent.v1' or intent.get('pairing_sha256')!=pairing_hash:
        raise SystemExit('ENROLLMENT_INTENT_PAIRING_MISMATCH')
    token=intent.get('client_device_token')
    if not isinstance(token,str) or not re.fullmatch(r'[A-Za-z0-9_-]{64}',token):
        raise SystemExit('ENROLLMENT_INTENT_INVALID')
else:
    token=secrets.token_urlsafe(48)
    raw=(json.dumps({'schema':'hara.commander-enrollment-intent.v1',
                     'pairing_sha256':pairing_hash,'client_device_token':token},
                    separators=(',',':'))+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as file:
        file.write(raw); file.flush(); os.fsync(file.fileno())
    directory=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try: os.fsync(directory)
    finally: os.close(directory)
print(token)
PYENROLLINTENT
}

resolve_tunnel_autostart() {
  local mode="${TUNNEL_AUTOSTART_RAW:-}"
  if [ -z "$mode" ] && [ -f "$CONFIG_FILE" ]; then
    mode="$(read_config_value HARA_COMMANDER_TUNNEL_AUTOSTART 2>/dev/null || true)"
  fi
  mode="${mode^^}"
  case "$mode" in
    ""|OFF|FALSE|NO|0) printf 'OFF\n' ;;
    ON|TRUE|YES|1) printf 'ON\n' ;;
    *) echo 'OPENAI_TUNNEL_AUTOSTART_INVALID' >&2; return 64 ;;
  esac
}

resolve_approval_mode() {
  local mode="${APPROVAL_MODE_RAW:-}"
  if [ -z "$mode" ] && [ -f "$CONFIG_FILE" ]; then
    mode="$(read_config_value HARA_COMMANDER_APPROVAL_MODE 2>/dev/null || true)"
  fi
  # Safe customer default: unattended mutations require explicit opt-in.
  [ -n "$mode" ] || mode="ASK_EVERY_ACTION"
  mode="${mode^^}"
  case "$mode" in
    ASK|ASK_EVERY_ACTION) printf 'ASK_EVERY_ACTION
' ;;
    SESSION|SESSION_TRUSTED) printf 'SESSION_TRUSTED
' ;;
    AUTO|ALWAYS|PERSISTENT|PERSISTENT_TRUSTED) printf 'PERSISTENT_TRUSTED
' ;;
    *) echo 'DEVICE_APPROVAL_MODE_INVALID' >&2; return 64 ;;
  esac
}

read_runtime_status_value() {
  local key="$1"
  [ -f "$STATUS_FILE" ] || return 1
  python3 - "$STATUS_FILE" "$key" <<'PY'
import json,sys
from pathlib import Path
obj=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
value=obj.get(sys.argv[2])
if value is None or value == "":
    raise SystemExit(1)
print(value)
PY
}

wait_for_agent_startup() {
  local expected_version="$1"
  local previous_started="${2:-}"
  local attempt
  for attempt in 1 2 3 4 5 6 7 8 9 10; do
    if python3 - "$STATUS_FILE" "$expected_version" "$previous_started" <<'PY'
import json,sys
from pathlib import Path
path=Path(sys.argv[1]); expected=sys.argv[2]; previous=sys.argv[3]
if not path.is_file():
    raise SystemExit(1)
try:
    obj=json.loads(path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(1)
started=str(obj.get("started_at_utc") or "")
version=str(obj.get("agent_version") or "")
if version == expected and started and started != previous:
    raise SystemExit(0)
raise SystemExit(1)
PY
    then
      return 0
    fi
    sleep 1
  done
  return 1
}

cleanup_prepared_release() {
  [ -z "$RELEASE_WORKDIR" ] || rm -rf -- "$RELEASE_WORKDIR"
  RELEASE_WORKDIR=""
  VERIFIED_AGENT_SOURCE=""
}

prepare_agent_release() {
  [ -z "$VERIFIED_AGENT_SOURCE" ] || return 0
  RELEASE_WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/hara-commander-release.XXXXXX")"
  chmod 700 "$RELEASE_WORKDIR"
  local relative status expected_version actual_version
  if ! curl -fsS --max-time 30 --max-redirs 0 "$BASE_URL/release/agent-manifest.json" -o "$RELEASE_WORKDIR/manifest.json"; then
    echo 'AGENT_RELEASE_MANIFEST_DOWNLOAD_FAILED' >&2; return 1
  fi
  if ! curl -fsS --max-time 30 --max-redirs 0 "$BASE_URL/release/agent-manifest.sig.json" -o "$RELEASE_WORKDIR/signature.json"; then
    echo 'AGENT_RELEASE_SIGNATURE_DOWNLOAD_FAILED' >&2; return 1
  fi
  if verify_release_manifest_signature "$RELEASE_WORKDIR/manifest.json" "$RELEASE_WORKDIR/signature.json"; then
    :
  else
    status=$?
    if [ "$status" -eq 12 ]; then echo 'RELEASE_SIGNATURE_KID_MISMATCH' >&2
    else echo 'AGENT_RELEASE_SIGNATURE_INVALID' >&2; fi
    return 1
  fi
  mkdir -p "$RELEASE_WORKDIR/agent" "$RELEASE_WORKDIR/install"
  for relative in agent/linux.py agent/windows.ps1 install/linux.sh install/windows.ps1; do
    if ! curl -fsS --max-time 30 --max-redirs 0 "$BASE_URL/$relative" -o "$RELEASE_WORKDIR/$relative"; then
      echo 'RELEASE_ASSET_DOWNLOAD_FAILED' >&2; return 1
    fi
  done
  if ! python3 - "$RELEASE_WORKDIR" "${BASH_SOURCE[0]}" "$ACTION" <<'PYRELEASEASSETS'
import hashlib,json,pathlib,re,sys
root=pathlib.Path(sys.argv[1]); running=pathlib.Path(sys.argv[2]); action=sys.argv[3]
files=("agent/linux.py","agent/windows.ps1","install/linux.sh","install/windows.ps1")
try:
    manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
    rows=manifest["files"]
    if manifest.get("schema")!="hara.commander-agent-release.v1" or not isinstance(rows,list):
        raise ValueError("schema")
    by_path={row["path"]:row for row in rows}
    if len(rows)!=4 or set(by_path)!=set(files): raise ValueError("fileset")
    version=manifest["agent_version"]
    if not isinstance(version,str) or not re.fullmatch(r"\d+\.\d+\.\d+",version):
        raise ValueError("version")
    for relative in files:
        row=by_path[relative]
        raw=(root/relative).read_bytes()
        if len(raw)>5*1024*1024 or type(row.get("bytes")) is not int or row["bytes"]!=len(raw):
            raise ValueError("size")
        if not re.fullmatch(r"[0-9a-f]{64}",str(row.get("sha256",""))) or hashlib.sha256(raw).hexdigest()!=row["sha256"]:
            raise ValueError("digest")
    windows=(root/"agent/windows.ps1").read_text(encoding="utf-8")
    if f'$AgentVersion = "{version}"' not in windows.splitlines():
        raise ValueError("windows-version")
    # The downloaded bootstrap itself must belong to the signed bundle. The
    # portal invokes a saved script, so no unsigned script can consume pairing.
    if action=="install" and (not running.is_file() or running.read_bytes()!=(root/"install/linux.sh").read_bytes()):
        raise ValueError("running-installer")
except Exception as exc:
    print("RELEASE_ASSET_DIGEST_MISMATCH:"+str(exc),file=sys.stderr)
    raise SystemExit(1)
PYRELEASEASSETS
  then
    return 1
  fi
  expected_version="$(python3 - "$RELEASE_WORKDIR/manifest.json" <<'PYVERSION'
import json,sys
print(json.load(open(sys.argv[1],encoding="utf-8"))["agent_version"])
PYVERSION
)"
  chmod 700 "$RELEASE_WORKDIR/agent/linux.py"
  actual_version="$(python3 "$RELEASE_WORKDIR/agent/linux.py" --version 2>/dev/null || true)"
  [ "$actual_version" = "$expected_version" ] || { echo 'AGENT_VERSION_MANIFEST_MISMATCH' >&2; return 1; }
  if ! python3 "$RELEASE_WORKDIR/agent/linux.py" --self-test >/dev/null; then
    echo 'AGENT_UPDATE_VALIDATION_FAILED' >&2; return 1
  fi
  VERIFIED_AGENT_SOURCE="$RELEASE_WORKDIR/agent/linux.py"
  printf 'HARA_COMMANDER_RELEASE_PRE_ENROLL=PASS\n'
}

download_agent() {
  prepare_agent_release
  mkdir -p "$BIN_DIR"
  mv -f "$VERIFIED_AGENT_SOURCE" "$AGENT"
  chmod 700 "$AGENT"
  cleanup_prepared_release
  printf 'HARA_COMMANDER_AGENT_INTEGRITY=PASS\n'
}

install_tunnel_client() {
  local arch asset expected tmp
  case "$(uname -m)" in
    x86_64|amd64)
      arch="amd64"
      expected="$TUNNEL_CLIENT_SHA256_AMD64"
      ;;
    aarch64|arm64)
      arch="arm64"
      expected="$TUNNEL_CLIENT_SHA256_ARM64"
      ;;
    *)
      echo "OPENAI_TUNNEL_CLIENT_ARCH_UNSUPPORTED" >&2
      return 31
      ;;
  esac
  asset="tunnel-client-v${TUNNEL_CLIENT_VERSION}-linux-${arch}.zip"
  tmp="$(mktemp "$BIN_DIR/.tunnel-client.XXXXXX.zip")"
  python3 - "$TUNNEL_CLIENT_BASE_URL/$asset" "$tmp" "$expected" "$TUNNEL_CLIENT" <<'PYTC'
import hashlib,io,os,pathlib,sys,urllib.error,urllib.request,zipfile
url,dest,expected,target=sys.argv[1:5]
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None
req=urllib.request.Request(url,headers={"accept":"application/zip","user-agent":"HARA-Commander-Installer-Tunnel/1"})
try:
    with urllib.request.build_opener(NoRedirect).open(req,timeout=45) as response:
        if response.status != 200:
            raise SystemExit("OPENAI_TUNNEL_CLIENT_DOWNLOAD_HTTP")
        raw=response.read(80*1024*1024+1)
except Exception as exc:
    raise SystemExit("OPENAI_TUNNEL_CLIENT_DOWNLOAD_FAILED") from exc
if len(raw)>80*1024*1024:
    raise SystemExit("OPENAI_TUNNEL_CLIENT_DOWNLOAD_TOO_LARGE")
if hashlib.sha256(raw).hexdigest()!=expected:
    raise SystemExit("OPENAI_TUNNEL_CLIENT_SHA256_MISMATCH")
pathlib.Path(dest).write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    names=z.namelist()
    if names.count("tunnel-client") != 1:
        raise SystemExit("OPENAI_TUNNEL_CLIENT_ARCHIVE_INVALID")
    info=z.getinfo("tunnel-client")
    if info.file_size<1024*1024 or info.file_size>80*1024*1024:
        raise SystemExit("OPENAI_TUNNEL_CLIENT_BINARY_SIZE_INVALID")
    binary=z.read(info)
t=pathlib.Path(target)
t.parent.mkdir(parents=True,exist_ok=True)
tmp_target=t.with_suffix(".tmp")
tmp_target.write_bytes(binary)
os.chmod(tmp_target,0o700)
tmp_target.replace(t)
os.chmod(t,0o700)
PYTC
  rm -f "$tmp"
  if ! "$TUNNEL_CLIENT" --version 2>/dev/null | grep -F "$TUNNEL_CLIENT_VERSION" >/dev/null; then
    echo "OPENAI_TUNNEL_CLIENT_VERSION_INVALID" >&2
    return 32
  fi
  printf 'HARA_COMMANDER_OPENAI_TUNNEL_CLIENT_VERSION=%s\n' "$TUNNEL_CLIENT_VERSION"
  printf 'HARA_COMMANDER_OPENAI_TUNNEL_CLIENT_INTEGRITY=PASS\n'
}

install_cli() {
  mkdir -p "$USER_BIN"
  ln -sfn "$AGENT" "$CLI"
  if [ ! -e "$USER_BIN/hara" ] && ! command -v hara >/dev/null 2>&1; then
    cat >"$USER_BIN/hara" <<'EOHARA'
#!/bin/sh
# HARA_COMMANDER_MANAGED_HARA_WRAPPER_V1
set -eu
if [ "${1:-}" != "commander" ]; then
  echo "Usage: hara commander [start|status|stop|mcp|doctor|support|approval-mode]" >&2
  exit 64
fi
shift
exec "$HOME/.local/bin/hara-commander" "${1:-status}"
EOHARA
    chmod 700 "$USER_BIN/hara"
  fi
  printf 'HARA_COMMANDER_CLI=%s\n' "$CLI"
}

status_agent() {
  local device_id="" enrolled=FALSE active=FALSE enabled=FALSE version="unknown" approval_mode=""
  device_id="$(read_config_value HARA_DEVICE_ID 2>/dev/null || true)"
  approval_mode="$(read_config_value HARA_COMMANDER_APPROVAL_MODE 2>/dev/null || true)"
  [ -n "$device_id" ] && enrolled=TRUE
  systemctl --user is-active --quiet "$SERVICE" 2>/dev/null && active=TRUE || true
  systemctl --user is-enabled --quiet "$SERVICE" 2>/dev/null && enabled=TRUE || true
  [ ! -f "$AGENT" ] || version="$(python3 "$AGENT" --version 2>/dev/null || echo unknown)"
  printf 'HARA_COMMANDER_DEVICE_ENROLLED=%s\n' "$enrolled"
  printf 'HARA_COMMANDER_AGENT_ACTIVE=%s\n' "$active"
  printf 'HARA_COMMANDER_AGENT_ENABLED=%s\n' "$enabled"
  printf 'HARA_COMMANDER_AGENT_VERSION=%s\n' "$version"
  [ -z "$approval_mode" ] || printf 'HARA_COMMANDER_APPROVAL_MODE=%s\n' "$approval_mode"
  [ -z "$device_id" ] || printf 'DEVICE_ID=%s\n' "$device_id"
  if [ -f "$AGENT" ]; then python3 "$AGENT" --session-status 2>/dev/null || true; fi
  printf 'DEVICE_TOKEN_EXPOSED=FALSE\n'
}

remote_device_action() {
  local action="$1"
  python3 - "$CONFIG_FILE" "$action" <<'PYREMOTE'
import json,sys,urllib.request,urllib.error
from pathlib import Path
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "REDIRECT_DENIED", headers, fp)
opener=urllib.request.build_opener(NoRedirectHandler)
path=Path(sys.argv[1]); action=sys.argv[2]
values={}
for raw in path.read_text(encoding="utf-8").splitlines():
    if "=" in raw:
        key,value=raw.split("=",1); values[key]=value
base=values.get("HARA_COMMANDER_URL","").rstrip("/")
token=values.get("HARA_DEVICE_TOKEN","")
device_id=values.get("HARA_DEVICE_ID","")
arch=values.get("HARA_DEVICE_ARCH","")
if not base or not token or not device_id:
    raise SystemExit(2)
if action=="heartbeat":
    endpoint="/api/device/heartbeat"
    payload={"device_id":device_id,"architecture":arch,"agent_version":"0.3.43","approval_mode":values.get("HARA_COMMANDER_APPROVAL_MODE","ASK_EVERY_ACTION")}
elif action=="revoke":
    endpoint="/api/device/revoke-self"
    payload={}
else:
    raise SystemExit(2)
req=urllib.request.Request(
    base+endpoint, data=json.dumps(payload,separators=(",",":")).encode(), method="POST",
    headers={"content-type":"application/json","accept":"application/json","user-agent":"HARA-Commander-Installer/0.3.43","authorization":"Bearer "+token},
)
try:
    with opener.open(req,timeout=15) as response:
        obj=json.loads(response.read().decode() or "{}")
except Exception:
    raise SystemExit(3)
if action=="heartbeat":
    if not obj.get("ok") or obj.get("device_id")!=device_id:
        raise SystemExit(4)
else:
    if not obj.get("ok") or obj.get("state")!="REVOKED" or obj.get("device_id")!=device_id:
        raise SystemExit(4)
PYREMOTE
}

rollback_enrolled_device() {
  [ -n "${DEVICE_ID:-}" ] && [ -n "${DEVICE_TOKEN:-}" ] || return 1
  printf '%s\n' "$DEVICE_TOKEN" | python3 -c '
import json,sys,urllib.request,urllib.error
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "REDIRECT_DENIED", headers, fp)
opener=urllib.request.build_opener(NoRedirectHandler)
base=sys.argv[1].rstrip("/")
device_id=sys.argv[2]
token=sys.stdin.readline().rstrip("\n")
if not device_id or not token: raise SystemExit(2)
req=urllib.request.Request(
    base+"/api/device/revoke-self", data=b"{}", method="POST",
    headers={"content-type":"application/json","accept":"application/json","authorization":"Bearer "+token,"user-agent":"HARA-Commander-Installer-Rollback/0.3.43"},
)
with opener.open(req,timeout=15) as response:
    obj=json.loads(response.read().decode() or "{}")
if not obj.get("ok") or obj.get("state")!="REVOKED" or obj.get("device_id")!=device_id:
    raise SystemExit(3)
' "$BASE_URL" "$DEVICE_ID"
}

cleanup_failed_install() {
  local rc="${1:-$?}"
  trap - EXIT
  if [ "$rc" -ne 0 ] && [ "${INSTALL_ENROLLED:-FALSE}" = TRUE ]; then
    local revoke_state=PENDING
    rollback_enrolled_device >/dev/null 2>&1 && revoke_state=PASS || true
    systemctl --user disable --now "$SERVICE" >/dev/null 2>&1 || true
    rm -f "$UNIT"
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    rm -rf "$BIN_DIR"
    rm -f "$CONFIG_FILE"
    if [ "$revoke_state" = PASS ]; then rm -f "$ENROLLMENT_INTENT"; fi
    rmdir "$CONFIG_DIR" >/dev/null 2>&1 || true
    printf 'HARA_COMMANDER_FAILED_INSTALL_ROLLBACK=%s\n' "$revoke_state" >&2
    [ "$revoke_state" = PASS ] || printf 'SERVER_DEVICE_REVOKE_PENDING=TRUE\n' >&2
  fi
  unset DEVICE_TOKEN || true
  exit "$rc"
}

verify_existing_enrollment_rejected() {
  python3 - "$CONFIG_FILE" <<'PYREENROLLCHECK'
import json,sys,urllib.request,urllib.error
from pathlib import Path
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "REDIRECT_DENIED", headers, fp)
opener=urllib.request.build_opener(NoRedirectHandler)
path=Path(sys.argv[1]); values={}
for raw in path.read_text(encoding="utf-8").splitlines():
    if "=" in raw:
        key,value=raw.split("=",1); values[key]=value
base=values.get("HARA_COMMANDER_URL","").rstrip("/")
token=values.get("HARA_DEVICE_TOKEN","")
device_id=values.get("HARA_DEVICE_ID","")
arch=values.get("HARA_DEVICE_ARCH","")
if not base or not token or not device_id:
    print("REENROLL_LOCAL_ENROLLMENT_INVALID",file=sys.stderr); raise SystemExit(12)
payload=json.dumps({"device_id":device_id,"architecture":arch,"agent_version":"0.3.43"},separators=(",",":")).encode()
req=urllib.request.Request(
    base+"/api/device/heartbeat", data=payload, method="POST",
    headers={"content-type":"application/json","accept":"application/json",
             "user-agent":"HARA-Commander-Reenroll-Check/0.3.43","authorization":"Bearer "+token},
)
try:
    with opener.open(req,timeout=15) as response:
        obj=json.loads(response.read().decode() or "{}")
        if response.status==200 and obj.get("ok") is True:
            print("REENROLL_REFUSED_CURRENT_DEVICE_STILL_ACTIVE",file=sys.stderr); raise SystemExit(13)
        print("REENROLL_AUTH_CHECK_AMBIGUOUS",file=sys.stderr); raise SystemExit(14)
except urllib.error.HTTPError as exc:
    if exc.code != 401:
        print("REENROLL_AUTH_CHECK_AMBIGUOUS",file=sys.stderr); raise SystemExit(14)
    try: obj=json.loads(exc.read().decode() or "{}")
    except Exception:
        print("REENROLL_AUTH_CHECK_AMBIGUOUS",file=sys.stderr); raise SystemExit(14)
    if obj.get("code") != "DEVICE_AUTH_INVALID":
        print("REENROLL_AUTH_CHECK_AMBIGUOUS",file=sys.stderr); raise SystemExit(14)
    print("HARA_COMMANDER_REENROLL_OLD_CREDENTIAL_REJECTED=PASS")
except Exception:
    print("REENROLL_AUTH_CHECK_AMBIGUOUS",file=sys.stderr); raise SystemExit(14)
PYREENROLLCHECK
}

cleanup_failed_reenroll() {
  local rc="${1:-$?}"
  trap - EXIT
  if [ "$rc" -ne 0 ] && [ "${INSTALL_ENROLLED:-FALSE}" = TRUE ]; then
    local revoke_state=PENDING
    rollback_enrolled_device >/dev/null 2>&1 && revoke_state=PASS || true
    if [ "${REENROLL_CONFIG_REPLACED:-FALSE}" = TRUE ] && [ -n "${REENROLL_BACKUP:-}" ] && [ -f "$REENROLL_BACKUP" ]; then
      mv -f "$REENROLL_BACKUP" "$CONFIG_FILE"
      chmod 600 "$CONFIG_FILE"
      if [ "${REENROLL_SERVICE_WAS_ACTIVE:-FALSE}" = TRUE ]; then
        systemctl --user restart "$SERVICE" >/dev/null 2>&1 || true
      else
        systemctl --user stop "$SERVICE" >/dev/null 2>&1 || true
      fi
    fi
    printf 'HARA_COMMANDER_FAILED_REENROLL_ROLLBACK=%s\n' "$revoke_state" >&2
    if [ "$revoke_state" = PASS ]; then rm -f "$ENROLLMENT_INTENT"; fi
    [ "$revoke_state" = PASS ] || printf 'SERVER_DEVICE_REVOKE_PENDING=TRUE\n' >&2
  fi
  [ -z "${REENROLL_BACKUP:-}" ] || rm -f "$REENROLL_BACKUP"
  unset DEVICE_TOKEN || true
  exit "$rc"
}

preflight_agent() {
  local manifest signature health persistence_ready=FALSE arch
  manifest="$(mktemp)"
  signature="$(mktemp)"
  health="$(mktemp)"
  trap 'rm -f "$manifest" "$signature" "$health"' RETURN
  curl -fsS --max-time 15 "$BASE_URL/api/health" -o "$health" || { echo 'COMMANDER_HEALTH_UNREACHABLE' >&2; return 10; }
  curl -fsS --max-time 15 "$BASE_URL/release/agent-manifest.json" -o "$manifest" || { echo 'AGENT_RELEASE_MANIFEST_UNREACHABLE' >&2; return 11; }
  curl -fsS --max-time 15 "$BASE_URL/release/agent-manifest.sig.json" -o "$signature" || { echo 'AGENT_RELEASE_SIGNATURE_UNREACHABLE' >&2; return 11; }
  verify_release_manifest_signature "$manifest" "$signature" || { echo 'AGENT_RELEASE_SIGNATURE_INVALID' >&2; return 11; }
  systemctl --user show-environment >/dev/null 2>&1 && persistence_ready=TRUE || true
  arch="$(uname -m)"
  python3 - "$health" "$manifest" "$BASE_URL" "$arch" "$persistence_ready" <<'PYPREFLIGHT'
import json,sys
health=json.load(open(sys.argv[1],encoding="utf-8"))
manifest=json.load(open(sys.argv[2],encoding="utf-8"))
if health.get("ok") is not True or health.get("service")!="hara-commander": raise SystemExit("COMMANDER_HEALTH_INVALID")
if manifest.get("schema")!="hara.commander-agent-release.v1": raise SystemExit("AGENT_RELEASE_MANIFEST_INVALID")
version=manifest.get("agent_version")
if not isinstance(version,str) or not version: raise SystemExit("AGENT_RELEASE_VERSION_INVALID")
ready=sys.argv[5]=="TRUE"
report={
  "schema":"hara.commander-device-preflight.v1",
  "platform":"LINUX",
  "architecture":sys.argv[4],
  "commander_url":sys.argv[3],
  "commander_health":True,
  "release_manifest":True,
  "release_signature":True,
  "stable_agent_version":version,
  "persistence":"systemd-user",
  "persistence_ready":ready,
  "mutation_performed":False,
}
print(json.dumps(report,separators=(",",":"),sort_keys=True))
if not ready: raise SystemExit(12)
PYPREFLIGHT
}

support_agent() {
  if [ -f "$AGENT" ]; then
    if python3 "$AGENT" support; then
      return 0
    fi
  fi
  local active=FALSE enabled=FALSE
  systemctl --user is-active --quiet "$SERVICE" 2>/dev/null && active=TRUE || true
  systemctl --user is-enabled --quiet "$SERVICE" 2>/dev/null && enabled=TRUE || true
  python3 - "$CONFIG_FILE" "$AGENT" "$UNIT" "$STATUS_FILE" "$active" "$enabled" <<'PYSUPPORT'
import hashlib,json,os,platform,stat,sys
from pathlib import Path
config_path=Path(sys.argv[1]); agent_path=Path(sys.argv[2]); unit_path=Path(sys.argv[3]); status_path=Path(sys.argv[4])
active=sys.argv[5]=="TRUE"; enabled=sys.argv[6]=="TRUE"
values={}
if config_path.is_file():
    for raw in config_path.read_text(encoding="utf-8").splitlines():
        if "=" in raw:
            key,value=raw.split("=",1)
            if key != "HARA_DEVICE_TOKEN": values[key]=value
version="unknown"
agent_sha=None
if agent_path.is_file():
    try:
        import subprocess
        version=subprocess.run([sys.executable,str(agent_path),"--version"],capture_output=True,text=True,timeout=5).stdout.strip() or "unknown"
    except Exception: pass
    agent_sha=hashlib.sha256(agent_path.read_bytes()).hexdigest()
mode=None
if config_path.exists(): mode=oct(stat.S_IMODE(config_path.stat().st_mode))[2:]
runtime={}
if status_path.is_file():
    try: runtime=json.loads(status_path.read_text(encoding="utf-8"))
    except Exception: runtime={}
report={
  "schema":"hara.commander-support-report.v1",
  "platform":"LINUX",
  "device_id":values.get("HARA_DEVICE_ID"),
  "architecture":values.get("HARA_DEVICE_ARCH") or platform.machine(),
  "commander_url":values.get("HARA_COMMANDER_URL"),
  "transport_mode":values.get("HARA_COMMANDER_TRANSPORT_MODE") or "OUTBOUND_RELAY",
  "agent_version":version,
  "agent_sha256":agent_sha,
  "config_present":config_path.is_file(),
  "config_mode":mode,
  "service_unit_present":unit_path.is_file(),
  "service_active":active,
  "service_enabled":enabled,
  "device_token_present":bool(config_path.is_file() and any(line.startswith("HARA_DEVICE_TOKEN=") for line in config_path.read_text(encoding="utf-8").splitlines())),
  "device_token_exposed":False,
  "last_successful_heartbeat_at_utc":runtime.get("last_successful_heartbeat_at_utc"),
  "last_runtime_error_code":runtime.get("last_runtime_error_code"),
  "last_runtime_error_at_utc":runtime.get("last_runtime_error_at_utc"),
}
print(json.dumps(report,separators=(",",":"),sort_keys=True))
PYSUPPORT
}

doctor_agent() {
  [ -f "$CONFIG_FILE" ] || { echo 'DEVICE_NOT_ENROLLED' >&2; return 5; }
  [ -f "$AGENT" ] || { echo 'AGENT_BINARY_MISSING' >&2; return 6; }
  [ -f "$UNIT" ] || { echo 'AGENT_SERVICE_NOT_INSTALLED' >&2; return 6; }
  # Manual-on-demand units are deliberately disabled at boot.
  systemctl --user is-active --quiet "$SERVICE" || { echo 'AGENT_SERVICE_NOT_ACTIVE' >&2; return 7; }
  python3 "$AGENT" --self-test >/dev/null || { echo 'AGENT_SELF_TEST_FAILED' >&2; return 8; }
  local transport
  transport="$(read_config_value HARA_COMMANDER_TRANSPORT_MODE 2>/dev/null || true)"
  if [ "$transport" = "LOCAL_TUNNEL" ]; then
    python3 "$AGENT" doctor || return $?
    printf 'COMMANDER_REMOTE_HEALTH=CONTROL_PLANE_OPTIONAL\n'
    status_agent
    return 0
  fi
  preflight_agent >/dev/null || { echo 'COMMANDER_REMOTE_HEALTH=FAIL' >&2; return 9; }
  printf 'HARA_COMMANDER_AGENT_DOCTOR=PASS\n'
  printf 'COMMANDER_REMOTE_HEALTH=PASS\n'
  printf 'COMMANDER_REMOTE_HEARTBEAT=SKIPPED_LOCAL_SESSION_REQUIRED\n'
  status_agent
}

trap cleanup_prepared_release EXIT
case "$ACTION" in
  status)
    status_agent; exit 0 ;;
  preflight)
    preflight_agent; exit $? ;;
  doctor)
    doctor_agent; exit $? ;;
  support)
    support_agent; exit $? ;;
  update)
    [ -f "$CONFIG_FILE" ] || { echo 'DEVICE_NOT_ENROLLED' >&2; exit 5; }
    [ -f "$UNIT" ] || { echo 'AGENT_SERVICE_NOT_INSTALLED' >&2; exit 6; }
    configured_url="$(read_config_value HARA_COMMANDER_URL 2>/dev/null || true)"
    [ -z "$configured_url" ] || BASE_URL="${configured_url%/}"
    previous_started="$(read_runtime_status_value started_at_utc 2>/dev/null || true)"
    UPDATE_SERVICE_WAS_ACTIVE=FALSE
    systemctl --user is-active --quiet "$SERVICE" 2>/dev/null && UPDATE_SERVICE_WAS_ACTIVE=TRUE || true
    existing_transport="$(read_config_value HARA_COMMANDER_TRANSPORT_MODE 2>/dev/null || true)"
    if [ "$existing_transport" = "LOCAL_TUNNEL" ]; then
      install_tunnel_client
    fi
    backup="$AGENT.rollback"
    rm -f "$backup"
    [ ! -f "$AGENT" ] || cp -p "$AGENT" "$backup"
    download_agent
    install_cli
    expected_version="$(python3 "$AGENT" --version)"
    systemctl --user daemon-reload
    if [ "$UPDATE_SERVICE_WAS_ACTIVE" = TRUE ]; then
      systemctl --user restart "$SERVICE"
      sleep 1
      if ! systemctl --user is-active --quiet "$SERVICE" || ! wait_for_agent_startup "$expected_version" "$previous_started"; then
        if [ -f "$backup" ]; then
          mv -f "$backup" "$AGENT"
          chmod 700 "$AGENT"
          systemctl --user restart "$SERVICE" || true
          sleep 1
          systemctl --user is-active --quiet "$SERVICE" && printf 'HARA_COMMANDER_AGENT_UPDATE_ROLLBACK=PASS\n' >&2
        fi
        echo 'HARA Commander Agent failed after update; previous agent restored when available.' >&2
        exit 7
      fi
      printf 'HARA_COMMANDER_AGENT_STARTUP_ATTESTATION=PASS\n'
    else
      # Updating a manually stopped agent must not establish a new connection.
      printf 'HARA_COMMANDER_AGENT_UPDATE_RUNTIME_ATTESTATION=SKIPPED_MANUAL_STOP\n'
    fi
    rm -f "$backup"
    printf 'HARA_COMMANDER_AGENT_UPDATE_SERVICE_WAS_ACTIVE=%s\n' "$UPDATE_SERVICE_WAS_ACTIVE"
    printf 'HARA_COMMANDER_AGENT_UPDATE=PASS\n'
    printf 'HARA_COMMANDER_AGENT_UPDATE_ROLLBACK_READY=TRUE\n'
    status_agent; exit 0 ;;
  uninstall)
    device_id="$(read_config_value HARA_DEVICE_ID 2>/dev/null || true)"
    revoke_state=NOT_REQUIRED
    if [ -f "$CONFIG_FILE" ] || [ -f "$ENROLLMENT_INTENT" ]; then revoke_state=PENDING; fi
    if [ -f "$CONFIG_FILE" ] && remote_device_action revoke; then revoke_state=PASS; fi
    systemctl --user disable --now "$SERVICE" >/dev/null 2>&1 || true
    systemctl --user disable --now hara-commander-openai-tunnel.service >/dev/null 2>&1 || true
    rm -f "$UNIT" "$SYSTEMD_DIR/hara-commander-openai-tunnel.service"
    rm -f "${XDG_CONFIG_HOME:-$HOME/.config}/tunnel-client/hara-commander.yaml"
    rmdir "${XDG_CONFIG_HOME:-$HOME/.config}/tunnel-client" >/dev/null 2>&1 || true
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    rm -f "$CLI"
    # Remove only the wrapper created by Commander. Never remove an
    # unrelated user-owned hara CLI, or follow a symlink placed at this path.
    if [ -f "$USER_BIN/hara" ] && [ ! -L "$USER_BIN/hara" ] \
       && grep -Fqx '# HARA_COMMANDER_MANAGED_HARA_WRAPPER_V1' "$USER_BIN/hara"; then
      rm -f "$USER_BIN/hara"
    fi
    rm -rf "$BIN_DIR"
    if [ "$revoke_state" = PENDING ]; then
      printf 'HARA_COMMANDER_AGENT_UNINSTALL=LOCAL_ONLY\n'
      [ -z "$device_id" ] || printf 'DEVICE_ID=%s\n' "$device_id"
      printf 'SERVER_DEVICE_REVOKE=PENDING\n'
      printf 'SERVER_DEVICE_REVOKE_PENDING=TRUE\n'
      printf 'DEVICE_TOKEN_EXPOSED=FALSE\n'
      exit 12
    fi
    rm -rf "$CONFIG_DIR"
    printf 'HARA_COMMANDER_AGENT_UNINSTALL=PASS\n'
    [ -z "$device_id" ] || printf 'DEVICE_ID=%s\n' "$device_id"
    printf 'SERVER_DEVICE_REVOKE=%s\n' "$revoke_state"
    printf 'DEVICE_TOKEN_EXPOSED=FALSE\n'
    exit 0 ;;
  re-enroll|reenroll)
    [ -f "$CONFIG_FILE" ] || { echo 'DEVICE_NOT_ENROLLED: use install.' >&2; exit 5; }
    [ -f "$AGENT" ] || { echo 'AGENT_BINARY_MISSING' >&2; exit 6; }
    [ -f "$UNIT" ] || { echo 'AGENT_SERVICE_NOT_INSTALLED' >&2; exit 6; }
    configured_url="$(read_config_value HARA_COMMANDER_URL 2>/dev/null || true)"
    [ -z "$configured_url" ] || BASE_URL="${configured_url%/}"
    verify_existing_enrollment_rejected
    REENROLL=TRUE
    REENROLL_OLD_DEVICE_ID="$(read_config_value HARA_DEVICE_ID 2>/dev/null || true)"
    systemctl --user is-active --quiet "$SERVICE" 2>/dev/null && REENROLL_SERVICE_WAS_ACTIVE=TRUE || true
    ;;
  install) ;;
  *) echo 'Usage: linux.sh [install|re-enroll|preflight|status|doctor|support|update|uninstall]' >&2; exit 64 ;;
esac

if [ "$REENROLL" != TRUE ] && [ -f "$CONFIG_FILE" ]; then
  cat >&2 <<'EOF_ALREADY'
DEVICE_ALREADY_ENROLLED
This computer already has a Commander enrollment.
If the device was revoked and you want to pair it again, run:
  bash linux.sh re-enroll
To inspect the current state, run:
  bash linux.sh status
EOF_ALREADY
  exit 8
fi

trap 'cleanup_prepared_release' EXIT
if [ "$REENROLL" != TRUE ]; then
  # All four release assets and the saved bootstrap must authenticate before
  # consuming a pairing token or creating a server-side device registration.
  prepare_agent_release
fi

APPROVAL_MODE="$(resolve_approval_mode)"
printf 'HARA Commander — Linux device pairing\n'
printf 'Approval mode: %s\n' "$APPROVAL_MODE"
IFS= read -r -s -p 'Pairing token: ' PAIRING_TOKEN </dev/tty
printf '\n'
[ -n "$PAIRING_TOKEN" ] || { echo 'Pairing token cannot be empty.' >&2; exit 3; }

DEVICE_NAME="${HOSTNAME:-$(hostname 2>/dev/null || echo linux-device)}"
ARCH="$(uname -m)"
PAIRING_HASH="$(printf '%s' "$PAIRING_TOKEN" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')"
DEVICE_TOKEN="$(prepare_enrollment_intent "$PAIRING_HASH")"

PAYLOAD="$(printf '%s\n%s\n' "$PAIRING_TOKEN" "$DEVICE_TOKEN" | python3 -c '
import json,sys
token=sys.stdin.readline().rstrip("\n")
device_token=sys.stdin.readline().rstrip("\n")
print(json.dumps({
  "pairing_token": token,
  "client_device_token": device_token,
  "device_name": sys.argv[1],
  "platform": "LINUX",
  "architecture": sys.argv[2],
  "agent_version": "0.3.43",
  "approval_mode": sys.argv[3],
}, separators=(",",":")))
' "$DEVICE_NAME" "$ARCH" "$APPROVAL_MODE")"

if ! RESPONSE="$(printf '%s' "$PAYLOAD" | curl -fsS --max-time 30   -H 'content-type: application/json'   -H 'accept: application/json'   --data-binary @-   "$BASE_URL/api/device/enroll-intent")"; then
  echo 'ENROLLMENT_ACK_UNKNOWN: rerun with the same pairing token to recover this intent.' >&2
  exit 12
fi

if ! PARSED="$(printf '%s' "$RESPONSE" | python3 -c '
import json,re,sys
try: obj=json.load(sys.stdin)
except (ValueError,UnicodeError): raise SystemExit('DEVICE_ENROLLMENT_RESPONSE_INVALID') from None
if not isinstance(obj,dict): raise SystemExit('DEVICE_ENROLLMENT_RESPONSE_INVALID')
for key in ("device_id","device_token"):
    value=obj.get(key)
    if not isinstance(value,str) or not value or "\n" in value or "\r" in value:
        raise SystemExit("DEVICE_ENROLLMENT_RESPONSE_INVALID")
if not re.fullmatch(r"HARA-DEVICE-[A-Za-z0-9_-]+",obj["device_id"]):
    raise SystemExit("DEVICE_ENROLLMENT_RESPONSE_INVALID")
print(obj["device_id"])
print(obj["device_token"])
')"; then
  echo 'ENROLLMENT_ACK_UNKNOWN: rerun with the same pairing token to recover this intent.' >&2
  exit 12
fi
readarray -t VALUES <<< "$PARSED"
if [ "${VALUES[1]:-}" != "$DEVICE_TOKEN" ]; then
  echo 'ENROLLMENT_ACK_UNKNOWN: device credential differs from the saved intent.' >&2
  exit 12
fi

DEVICE_ID="${VALUES[0]}"
unset PAIRING_TOKEN PAIRING_HASH RESPONSE PAYLOAD PARSED VALUES
INSTALL_ENROLLED=TRUE
if [ "$REENROLL" = TRUE ]; then
  REENROLL_BACKUP="$(mktemp "$CONFIG_DIR/.device.env.reenroll.XXXXXX")"
  cp -p "$CONFIG_FILE" "$REENROLL_BACKUP"
  chmod 600 "$REENROLL_BACKUP"
  trap 'status=$?; cleanup_prepared_release || true; cleanup_failed_reenroll "$status"' EXIT
else
  trap 'status=$?; cleanup_prepared_release || true; cleanup_failed_install "$status"' EXIT
fi

if [ -n "$TRANSPORT_MODE_RAW" ]; then
  case "$(printf '%s' "$TRANSPORT_MODE_RAW" | tr '[:lower:]' '[:upper:]' | tr '-' '_')" in
    LOCAL_TUNNEL|TUNNEL|LOCAL) TRANSPORT_MODE="LOCAL_TUNNEL" ;;
    OUTBOUND_RELAY|RELAY|LEGACY) TRANSPORT_MODE="OUTBOUND_RELAY" ;;
    *) echo 'DEVICE_TRANSPORT_MODE_INVALID' >&2; exit 64 ;;
  esac
elif [ "$REENROLL" = TRUE ]; then
  TRANSPORT_MODE="$(read_config_value HARA_COMMANDER_TRANSPORT_MODE 2>/dev/null || true)"
  [ -n "$TRANSPORT_MODE" ] || TRANSPORT_MODE="OUTBOUND_RELAY"
else
  # Public plugin onboarding uses the Cloudflare customer MCP gateway;
  # no OpenAI Platform API key/tunnel required for a normal customer.
  TRANSPORT_MODE="OUTBOUND_RELAY"
fi

TUNNEL_AUTOSTART="$(resolve_tunnel_autostart)"
if [ "$TRANSPORT_MODE" != "LOCAL_TUNNEL" ] && [ "$TUNNEL_AUTOSTART" != "OFF" ]; then
  echo "OPENAI_TUNNEL_AUTOSTART_REQUIRES_DIRECT_TRANSPORT" >&2
  exit 64
fi
umask 077
mkdir -p "$CONFIG_DIR" "$BIN_DIR" "$SYSTEMD_DIR"
if [ "$TRANSPORT_MODE" = "LOCAL_TUNNEL" ]; then
  install_tunnel_client
fi
cat >"$CONFIG_FILE" <<EOF
HARA_COMMANDER_URL=$BASE_URL
HARA_DEVICE_ID=$DEVICE_ID
HARA_DEVICE_TOKEN=$DEVICE_TOKEN
HARA_DEVICE_ARCH=$ARCH
HARA_COMMANDER_APPROVAL_MODE=$APPROVAL_MODE
HARA_COMMANDER_TRANSPORT_MODE=$TRANSPORT_MODE
HARA_COMMANDER_TUNNEL_AUTOSTART=$TUNNEL_AUTOSTART
EOF
chmod 600 "$CONFIG_FILE"

if [ "$REENROLL" = TRUE ]; then
  REENROLL_CONFIG_REPLACED=TRUE
  expected_version="$(python3 "$AGENT" --version 2>/dev/null || true)"
  [ -n "$expected_version" ] || { echo 'AGENT_VERSION_INVALID' >&2; exit 6; }
  previous_started="$(read_runtime_status_value started_at_utc 2>/dev/null || true)"
  # Re-enrollment verifies startup once but does not change an inactive
  # agent into a persistent background connection.
  if [ "$REENROLL_SERVICE_WAS_ACTIVE" = TRUE ]; then
    systemctl --user restart "$SERVICE"
  else
    systemctl --user start "$SERVICE"
  fi
  sleep 1
  if ! systemctl --user is-active --quiet "$SERVICE" || ! wait_for_agent_startup "$expected_version" "$previous_started"; then
    echo 'HARA Commander Agent failed re-enroll startup attestation.' >&2
    exit 4
  fi
  if [ "$REENROLL_SERVICE_WAS_ACTIVE" != TRUE ]; then
    systemctl --user stop "$SERVICE"
  fi
  install_cli
  printf 'HARA_COMMANDER_AGENT_STARTUP_ATTESTATION=PASS\n'
  INSTALL_ENROLLED=FALSE
  trap - EXIT
  rm -f "$ENROLLMENT_INTENT"
  rm -f "$REENROLL_BACKUP"
  REENROLL_BACKUP=""
  unset DEVICE_TOKEN
  printf 'HARA_COMMANDER_DEVICE_REENROLL=PASS\n'
  printf 'OLD_DEVICE_AUTHORITY_RESURRECTED=FALSE\n'
  [ -z "${REENROLL_OLD_DEVICE_ID:-}" ] || printf 'OLD_DEVICE_ID=%s\n' "$REENROLL_OLD_DEVICE_ID"
  printf 'DEVICE_ID=%s\n' "$DEVICE_ID"
  printf 'DEVICE_TOKEN_EXPOSED=FALSE\n'
  exit 0
fi

download_agent
install_cli
expected_version="$(python3 "$AGENT" --version)"

cat >"$UNIT" <<EOF
[Unit]
Description=HARA Commander Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$AGENT
# The enrolled agent reconnects after reboot; command approvals remain scoped.
Restart=on-failure
RestartSec=5
NoNewPrivileges=yes
PrivateTmp=yes

[Install]
WantedBy=default.target
EOF
chmod 600 "$UNIT"

systemctl --user daemon-reload
# Persist the enrolled device identity across restarts without weakening the
# per-action approval policy. Manual-only remains an explicit advanced option.
AGENT_AUTOSTART="${HARA_COMMANDER_AGENT_AUTOSTART:-ON}"
case "$AGENT_AUTOSTART" in
  ON)
    systemctl --user enable --now "$SERVICE"
    if ! systemctl --user is-enabled --quiet "$SERVICE"; then
      echo 'AGENT_AUTOSTART_ENABLE_FAILED' >&2
      exit 8
    fi
    # Keep the user manager available after logoff where logind permits it.
    if command -v loginctl >/dev/null 2>&1; then
      loginctl enable-linger "$(id -un)" >/dev/null 2>&1 || true
    fi
    ;;
  OFF)
    systemctl --user disable "$SERVICE" >/dev/null 2>&1 || true
    systemctl --user start "$SERVICE"
    ;;
  *)
    echo 'INVALID_AGENT_AUTOSTART_MODE' >&2
    exit 8
    ;;
esac

sleep 1
if ! systemctl --user is-active --quiet hara-commander-agent.service || ! wait_for_agent_startup "$expected_version" ""; then
  echo 'HARA Commander Agent failed startup attestation.' >&2
  exit 4
fi
printf 'HARA_COMMANDER_AGENT_STARTUP_ATTESTATION=PASS\n'

INSTALL_ENROLLED=FALSE
trap - EXIT
rm -f "$ENROLLMENT_INTENT"
unset DEVICE_TOKEN
printf 'HARA_COMMANDER_DEVICE_ENROLLMENT=PASS\n'
printf 'HARA_COMMANDER_AGENT_SERVICE=ACTIVE_LOCAL_CONTROL_PLANE\n'
printf 'HARA_COMMANDER_AGENT_AUTOSTART=%s\n' "$AGENT_AUTOSTART"
printf 'HARA_COMMANDER_AGENT_START_MODE=%s\n' "$([ "$AGENT_AUTOSTART" = ON ] && echo AUTO_RECONNECT || echo MANUAL)"
printf 'DEVICE_ID=%s\n' "$DEVICE_ID"
printf 'DEVICE_TOKEN_EXPOSED=FALSE\n'
printf 'HARA_COMMANDER_APPROVAL_MODE=%s\n' "$APPROVAL_MODE"
printf 'HARA_COMMANDER_TRANSPORT_MODE=%s\n' "$TRANSPORT_MODE"
printf 'HARA_COMMANDER_TUNNEL_AUTOSTART=%s\n' "$TUNNEL_AUTOSTART"
if [ "$TRANSPORT_MODE" = "LOCAL_TUNNEL" ]; then
  printf 'HARA_COMMANDER_TUNNEL_AUTOSTART_PENDING_CONFIGURATION=TRUE\n'
  printf 'NEXT_COMMAND=hara-commander tunnel configure\n'
  printf 'DIRECT_CONNECT_COMMAND=hara-commander tunnel connect\n'
  printf 'DIRECT_OPENAI_PLATFORM_TUNNEL_REQUIRED=TRUE\n'
  printf 'TUNNEL_MANUAL_START_COMMAND=hara-commander tunnel start\n'
  printf 'TUNNEL_MANUAL_STOP_COMMAND=hara-commander tunnel stop\n'
else
  printf 'HARA_COMMANDER_CLOUD_PLUGIN_MODE=TRUE\n'
  printf 'OPENAI_PLATFORM_API_KEY_REQUIRED=FALSE\n'
  printf 'NEXT_STEP=Conecte o ChatGPT ao HARA Commander e entre pelo HARA Identity\n'
  printf 'CUSTOMER_MCP_ENDPOINT=https://commander.haralabs.com.br/api/mcp?profile=simple\n'
fi
printf 'OPERATOR_SESSION_COMMAND=hara-commander start\n'
printf 'MANUAL_CONNECTION_COMMAND=hara-commander start\n'
printf 'STATUS_COMMAND=hara-commander status\n'
printf 'STOP_COMMAND=hara-commander stop\n'
printf 'LOCAL_MCP_COMMAND=hara-commander mcp\n'
printf 'AUTHORIZATION_COMMAND=hara-commander authorize\n'
printf 'SESSION_AUTHORITY=LOCAL_OPERATOR_TERMINAL\n'
